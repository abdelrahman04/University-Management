package Main;

import Engine.universityManager;

import java.security.MessageDigest;
import java.security.MessageDigestSpi;

public class Main {


    public static void main(String[] args) {
        universityManager engine =new universityManager();
        engine.start();
    }


}