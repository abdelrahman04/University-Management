package Account;

import Material.Course;
import Material.Grade;
import Material.Requests;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public class StudentAccount extends UserAccount implements Requests, Serializable {
    static final long serialVersionUID =
            -5849794470654667210L;
    private String id;
    private double balance;
    private ArrayList<Course> courses=new ArrayList<>();
    private boolean financialAided =false;
    private HashMap<Course, Grade> grades=new HashMap<>();
    private ArrayList<HashMap<Course, Grade>> all_grades =new ArrayList<>();
    private int Credit_hours =0;

    public StudentAccount() {
    }

    public StudentAccount(String email, String name, String password, double balance) {
        super(email, name, password);
        this.balance = balance;
        this.id=UUID.randomUUID().toString().replace("-", "");
    }
    public boolean isFinancialAided() {
        return financialAided;
    }
    public void setFinancialAided(boolean financialAided) {
        this.financialAided = financialAided;
    }
    public String getId() {
        return id;
    }
    /*public void setId(String id) {
        this.id = id;
    }*/
    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }
    public ArrayList<Course> getCourses() {
        return courses;
    }
    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }
    public HashMap<Course, Grade> getGrades() {
        return grades;
    }
    public void setGrades(HashMap<Course, Grade> grades) {
        this.grades = grades;
    }

    public ArrayList<HashMap<Course, Grade>> getAll_grades() {
        return all_grades;
    }

    public void setAll_grades(ArrayList<HashMap<Course, Grade>> all_grades) {
        this.all_grades = all_grades;
    }

    public int getCredit_hours() {
        return Credit_hours;
    }
    public void setCredit_hours(int credit_hours) {
        this.Credit_hours = credit_hours;
    }


    public boolean Register_Course(@NotNull Course course){
        if(course.getStudents_enrolled().size()>=course.getMax_students()||(course.getCredit_hours()*1000>this.getBalance()&&!financialAided)) {
            System.out.println("couldn't register course1");
            return false;
        }
        if(grades.containsKey(course)) {
            System.out.println("couldn't register course2");
            return false;
        }
        AtomicBoolean Found=new AtomicBoolean(false);
        all_grades.forEach(Grade->{
            if(Grade.containsKey(course)&&Grade.get(course)!=Material.Grade.F)
                Found.set(true);
        });
        if(Found.get()) {
            System.out.println("couldn't register course3");
            return false;
        }
        course.getStudents_enrolled().add(this);
        this.courses.add(course);
        grades.put(course, Grade.NULL);
        if(!financialAided)
        this.setBalance(this.balance-course.getCredit_hours()*100);
        this.setCredit_hours(getCredit_hours()+course.getCredit_hours());
        System.out.println("registered course successfully");
        return true;
    }

    public void Remove_Course(Course course){
        this.courses.remove(course);
        grades.remove(course);
        if(!financialAided)
            this.setBalance(this.balance+course.getCredit_hours()*100);
        this.setCredit_hours(getCredit_hours()-course.getCredit_hours());
    }

    public void Show_My_Courses(){
        for (int i = 0; i < getCourses().size(); ++i) {
            System.out.println(courses.get(i).toString());
        }
    }
    public void show_grades(){
        grades.forEach((c,g)->{
            System.out.println(c.toString()+"Material.Grade: "+g+"\n");
        });
    }

    @Override
    public String toString() {
        return "Student Name: "+getName()+"\nId: "+id;
    }

    @Override
    public String Print_Request() {
        return String.format("Student Name: %s\nId: %s\nBalance: %f",getName(),getId(),getBalance());
    }
}
