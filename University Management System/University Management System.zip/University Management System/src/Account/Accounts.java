package Account;

import Engine.universityManager;
import Material.Course;

public abstract class Accounts {

    public abstract boolean compare(String user,String password);
}
