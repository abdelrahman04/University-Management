package Account;

import Engine.universityManager;
import Material.Course;
import Material.Requests;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TaAccount extends UserAccount implements Requests , Serializable {
    static final long serialVersionUID =
            -5849794470654667211L;
    private String specialization;
    private ArrayList<Course> courses=new ArrayList<>();

    public TaAccount(String email, String name, String password, String specialization) {
        super(email, name, password);
        this.specialization = specialization;
    }
    public String getSpecialization() {
        return specialization;
    }
    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }
    public ArrayList<Course> getCourses() {
        return courses;
    }
    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }

    public TaAccount() {
    }

    public void Show_Courses(){
        Stream<Course> stream= universityManager.courses.stream();
        List x=stream.filter((c)->c.toString().contains(specialization)).collect(Collectors.toList());
        x.forEach(o -> System.out.println(o.toString()));
    }

    public boolean Register_Course(@NotNull Course course){
        if(course.getInstructor()!=null||this.getCourses().size()>2){
            System.out.println("Failed to register course");
            return false;
        }
        course.setInstructor(this);
        this.courses.add(course);
        System.out.println("Registered course successfully");
        return true;
    }

    public void Remove_Course(Course course){
        ArrayList<StudentAccount> Student_List = course.getStudents_enrolled();
        Student_List.forEach(student-> student.Remove_Course(course));
        universityManager.courses.remove(course);
        courses.remove(course);
    }

    public void Show_My_Courses(){
        courses.forEach(course->System.out.println(course.toString()));
    }

    public void View_My_Students(){
        for(int i=0;i<courses.size();++i){
            System.out.println("student for the "+(i+1)+" course\n"+courses.get(i));
            var students=courses.get(i).getStudents_enrolled();
            students.forEach(student->System.out.println(student.toString()));
        }
    }

    @Override
    public String Print_Request() {
        return String.format("Teacher Name: %s\nSpecialization: %s",getName(),getSpecialization());
    }
}
