package Account;

import Account.Accounts;
import Material.Course;
import org.jetbrains.annotations.NotNull;

import java.io.Serializable;

public abstract class UserAccount extends Accounts implements Serializable {
    static final long serialVersionUID =
            -5849794470654667215L;
    private String email;
    private String name;
    private String password;

    public String getPassword() {
        return password;
    }

    public UserAccount(String email, String name, String password) {
        this.email = email;
        this.name = name;
        this.password = password;
    }
    public String getName() {
        return name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public abstract void Show_My_Courses();
    public abstract boolean Register_Course(@NotNull Course course);

    public UserAccount() {
    }

    public abstract void Remove_Course(Course course);

    public boolean compare(String user,String password){
        return this.getName().equals(user)&&password.equals(this.password);
    }

}