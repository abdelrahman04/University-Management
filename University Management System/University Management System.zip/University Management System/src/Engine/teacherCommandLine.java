package Engine;

import Account.TaAccount;
import Material.Course;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class teacherCommandLine {

    public static void commandline(String input){
        int x;
        switch(input){
            case "1":help();break;
            case "2":universityManager.showAllCourses();break;
            case "3":universityManager.showMyCourses();break;
            case "4":universityManager.registerCourse();break;
            case "5":withdrawCourse();break;
            case "6":viewMyStudents();break;
            case "7":universityManager.signOut();break;
            default:universityManager.undefinedCommand();
        }

    }
    public static void help(){
        System.out.println("please enter the number of the command you want\nCommands:\n1-help\n2-show all courses\n3-show my courses\n4-register course\n5-withdraw course\n6-view all my students\n7-sign out");
    }
    public static void withdrawCourse(){

        try {
            System.out.println("enter your the name of the course you want to withdraw: ");
            String name= universityManager.Reader.readLine();
            AtomicBoolean found= new AtomicBoolean(false);
            AtomicReference<Course> course_found = new AtomicReference<>();
            ((TaAccount) universityManager.currentUser).getCourses().forEach(course->{
                if(course.getName().equals(name)){
                    course_found.set(course);
                    found.set(true);
                }
            });
            if(found.get())
                ((TaAccount) universityManager.currentUser).Remove_Course(course_found.get());
            else{
                System.out.println("No course with this name");
            }


        } catch (IOException e) {
            System.out.println("No Input received");
        }catch(NumberFormatException e){
            System.out.println("Wrong format");
        }


    }

    public static void viewMyStudents(){
        ((TaAccount) universityManager.currentUser).View_My_Students();
    }


}
