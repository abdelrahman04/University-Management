package Engine;

import Account.*;
import Material.Course;
import Material.Grade;
import Material.Requests;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class universityManager {

    public static ArrayList<StudentAccount> Students= new ArrayList<>();
    public static HashMap<String,StudentAccount> studentLogins=new HashMap<>();
    public static ArrayList<TaAccount> Teachers= new ArrayList<>();
    public static HashMap<String,TaAccount> teacherLogins=new HashMap<>();

    public static ArrayList<Course> courses = new ArrayList<>();
    public static ArrayList<Requests> accountRequests =new ArrayList<>();
    public static ArrayList<Requests> financialRequests =new ArrayList<>();
    public static Admin admin=new Admin("admin","admin");
    public static Accounts currentUser;
    public static BufferedReader Reader = new BufferedReader(
            new InputStreamReader(System.in));
    public static Integer semesterCount =0;
    public static Boolean semesterRunning =false;
    public static int lastSaved =10;
    public static nullCommandLine nullCommandline=new nullCommandLine();
    public static adminCommandLine adminCommandline=new adminCommandLine();
    public static studentCommandLine studentCommandline=new studentCommandLine();
    public static teacherCommandLine teacherCommandline=new teacherCommandLine();
    public static ExecutorService executor =
            Executors.newCachedThreadPool();

    public universityManager(){
        read();
    }
    public void start(){

        nullCommandLine.help();
        while (true){
            String input;
            try {
                input= Reader.readLine();
            } catch (IOException e) {
                System.out.println("No available input to read from");
                continue;
            }
            if(input.equals("save")){
                multiThreadSave();
            } else if(currentUser ==null)
                nullCommandline.commandline(input);
            else if(currentUser instanceof Admin)
                adminCommandLine.commandline(input);
            else if(currentUser instanceof TaAccount)
                teacherCommandline.commandline(input);
            else if(currentUser instanceof StudentAccount)
                studentCommandline.commandline(input);
            setLast_saved(lastSaved -1);

        }
    }



    public static void setLast_saved(int last_save) {
        if(last_save<0)
            multiThreadSave();
        universityManager.lastSaved = last_save<0?10:last_save;
    }
    public static void removeCourse(Course course){
        ArrayList<StudentAccount> Student_List = course.getStudents_enrolled();
        Student_List.forEach(student-> student.Remove_Course(course));
        universityManager.courses.remove(course);
    }





    public static void undefinedCommand(){
        System.out.println("Wrong command\nenter help to view list of commands");
    }

    public static void signOut(){
        currentUser =null;

        System.out.println("signed out successfully");
        nullCommandLine.help();
    }

    public static void multiThreadSave(){
        executor.execute(()->save());
    }



    public static void save(){
        Path path = Paths.get("DataBase.ser");
        try {
            Files.newBufferedWriter(path , StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            System.out.println("Error erasing old file");
        }

        try (ObjectOutputStream Out_Stream = new ObjectOutputStream(new FileOutputStream("DataBase.ser"))){

            Out_Stream.writeObject(Students);
            Out_Stream.writeObject(studentLogins);
            Out_Stream.writeObject(Teachers);
            Out_Stream.writeObject(teacherLogins);
            Out_Stream.writeObject(courses);
            Out_Stream.writeObject(accountRequests);
            Out_Stream.writeObject(financialRequests);
            Out_Stream.writeObject(semesterCount);
            Out_Stream.writeObject(semesterRunning);
        } catch (IOException ex) {
            System.out.println("saving failed");
        }
    }
    public static void read(){
        //with resources
        try {
            ObjectInputStream In_Stream = new ObjectInputStream(new FileInputStream("DataBase.ser"));
            Students=(ArrayList<StudentAccount>) In_Stream.readObject();
            studentLogins=(HashMap<String, StudentAccount>) In_Stream.readObject();
            Teachers=(ArrayList<TaAccount>) In_Stream.readObject();
            teacherLogins=(HashMap<String, TaAccount>) In_Stream.readObject();
            courses=(ArrayList<Course>) In_Stream.readObject();
            accountRequests =(ArrayList<Requests>) In_Stream.readObject();
            financialRequests =(ArrayList<Requests>) In_Stream.readObject();
            semesterCount =(Integer) In_Stream.readObject();
            semesterRunning =(Boolean)In_Stream.readObject();
            In_Stream.close();

        } catch (Exception ex) {
            System.out.println("reading data base failed");
        }
    }

    public static void showAllCourses(){
        //el null yetla3 foo2
        if( currentUser instanceof TaAccount)
            ((TaAccount) currentUser).Show_Courses();
        else
        courses.forEach(course->System.out.println(course.toString()));
    }
    public static void showMyCourses(){
        if(currentUser !=null)
            if(currentUser instanceof Admin)
                System.out.println("You are the admin");
            else
            ((UserAccount) currentUser).Show_My_Courses();
        else
            System.out.println("You are not signed in");
    }

    public static void registerCourse(){
        if(currentUser !=null&&!(currentUser instanceof Admin)) {
            try {
                System.out.println("enter your the name of the course you want to register: ");
                String name= Reader.readLine();
                AtomicBoolean found= new AtomicBoolean(false);
                AtomicReference<Course> course_found = new AtomicReference<>();

                courses.forEach(course->{
                    if(course.getName().equals(name)) {
                        course_found.set(course);
                        found.set(true);
                    }
                });
                if(found.get())
                ((UserAccount) currentUser).Register_Course(course_found.get());
                else{
                    System.out.println("No course with this name");
                }


            } catch (IOException e) {
                System.out.println("No Input received");
            }catch(NumberFormatException e){
                System.out.println("Wrong format");
            }
        }else{
            System.out.println("You need to be signed in as a teacher or a student");
        }
    }

}
