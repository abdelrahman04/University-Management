package Engine;

import Account.Admin;
import Account.StudentAccount;
import Account.TaAccount;
import Material.Course;
import Material.Grade;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class adminCommandLine {
    public static Grade[]Grades={Grade.A,Grade.B,Grade.C,Grade.D,Grade.E,Grade.F};
    public static long startTime=0;
    public static double remainingSemesterTime =4*60;
    public static AtomicBoolean pausedSemester=new AtomicBoolean(false);
    public static void commandline(String input){
        switch (input) {
            case "1" -> help();
            case "2" -> reset();
            case "3" -> startSemester();
            case "4" -> endSemester();
            case "5" -> showAccountRequests();
            case "6" -> handleAccountRequest();
            case "7" -> showFinancialRequests();
            case "8" -> handleFinancialRequest();
            case "9" -> universityManager.showAllCourses();
            case "10" -> addCourse();
            case "11" -> modifyStudentBalance();
            case "12" -> pauseSemester();
            case "13" -> continueSemester();
            case "14" -> universityManager.signOut();
            default -> universityManager.undefinedCommand();
        }

    }
    public static void reset(){
        universityManager.Students= new ArrayList<>();
        universityManager.Teachers= new ArrayList<>();
        universityManager.courses = new ArrayList<>();
        universityManager.accountRequests =new ArrayList<>();
        universityManager.financialRequests =new ArrayList<>();
        universityManager.currentUser =null;
        universityManager.semesterCount =0;
        universityManager.semesterRunning =false;
        universityManager.lastSaved =10;
        universityManager.multiThreadSave();
        System.out.println("database emptied successfully");
    }
    public static void help(){
        System.out.println("please enter the number of the command you want\nCommands:\n1-help\n2-reset database\n3-start semester\n4-end semester\n5-show account requests\n6-handle account request\n7-show financial requests\n8-handle financial request\n9-show all courses\n10-add course\n11-modify student balance\n12-pause semester\n13-continue semester\n14-sign out");
    }
    public static void startSemester(){
        if(universityManager.semesterRunning){
            System.out.println("you cant start a running semester");
        }
        AtomicBoolean Found=new AtomicBoolean(false);
        universityManager.Students.forEach(student->{
            if(student.getCredit_hours()<9&&student.getCredit_hours()!=0){
                Found.set(true);
                System.out.println();
                System.out.println("Student "+student.getName()+" has less than 9 credit hours\n semester cant start");
            }
        });
        universityManager.courses.forEach(course -> {
            if(course.getInstructor()==null){
                universityManager.removeCourse(course);
            }
        });
        if(Found.get())
            return;
        System.out.println("Semester started");
        universityManager.Students.forEach(student->{
            student.getAll_grades().add(student.getGrades());
        });
        universityManager.semesterCount++;
        universityManager.semesterRunning =true;
        startTime=System.currentTimeMillis();
        remainingSemesterTime =60;
        universityManager.executor.execute(()->startCountdown());
        universityManager.multiThreadSave();
    }
    public static void startCountdown(){
        while(true){
            remainingSemesterTime -=(System.currentTimeMillis()-startTime)/1000;
            startTime=System.currentTimeMillis();
            if(remainingSemesterTime <=0){
                endSemester();
                break;
            }
            System.out.println("remaining time in semester: "+remainingSemesterTime);
            if(pausedSemester.get()){
                break;
            }
            try {
                TimeUnit.SECONDS.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }
    public static void pauseSemester(){
        if (!universityManager.semesterRunning||pausedSemester.get()){
            System.out.println("sem not running");
            return;
        }
        pausedSemester.set(true);
        System.out.println("paused");
    }
    public static void continueSemester(){
        if(!pausedSemester.get()){
            System.out.println("you cant continue an unpaused semester");
            return;
        }
        pausedSemester.set(false);
        startTime=System.currentTimeMillis();
        universityManager.executor.execute(()->startCountdown());
        System.out.println("continued");
    }

    public static void endSemester(){
        if(!universityManager.semesterRunning){
            System.out.println("semester is not running");
            return;
        }
        universityManager.Students.forEach(student->{
            int random_grade=(int)(Math.random()*6);
            student.getAll_grades().get(universityManager.semesterCount -1).replaceAll((course, grade) -> grade=Grades[random_grade]);
        });
        universityManager.Students.forEach(student->{
            student.setGrades(new HashMap<>());
            student.setCourses(new ArrayList<>());
            student.setCredit_hours(0);
        });
        universityManager.semesterRunning =false;
        System.out.println("semester ended");
        universityManager.multiThreadSave();
    }

    public static void showAccountRequests(){
        AtomicInteger counter= new AtomicInteger(1);
        universityManager.accountRequests.forEach(request->System.out.println((counter.getAndIncrement())+"-" +request.Print_Request()));
    }

    public static void showFinancialRequests(){
        universityManager.financialRequests.forEach(request->System.out.println(request.Print_Request()+"\nHas requested financial aid"));
    }

    public static void handleAccountRequest(){
            try {
                System.out.println("Do you want to accept or reject: ");
                String response=universityManager.Reader.readLine();
                boolean response_flag=false;
                if(response.equals("accept"))
                    response_flag=true;
                else if (response.equals("reject"))
                    response_flag=false;
                else{
                    System.out.println("Invalid input");
                    return;
                }
                System.out.println("enter the number of the requests you want to handle separated with commas");
                String requests[]=universityManager.Reader.readLine().split(",");
                Arrays.sort(requests);
                int requestNumbers[]=new int[requests.length];
                int pointer=0;
                for(String request:requests){
                    int request_number= Integer.parseInt(request);
                    if(request_number> universityManager.accountRequests.size()||request_number<=0) {
                        System.out.println("Invalid Request Numbers");
                        return;
                    }
                    requestNumbers[pointer++]=request_number;
                }
                for(int request_number=requestNumbers.length-1;request_number>=0;request_number--) {
                    var current_request = universityManager.accountRequests.get(requestNumbers[request_number] - 1);
                    if (response_flag) {
                        if (current_request instanceof TaAccount) {
                            universityManager.Teachers.add((TaAccount) current_request);
                            universityManager.teacherLogins.put(((TaAccount) current_request).getName(), (TaAccount) current_request);
                        } else {
                            universityManager.Students.add((StudentAccount) current_request);
                            universityManager.studentLogins.put(((StudentAccount) current_request).getName(), (StudentAccount) current_request);
                        }
                        System.out.println("Request Accepted");
                    } else
                        System.out.println("Request Rejected");
                    universityManager.accountRequests.remove(current_request);
                }
            } catch (IOException e) {
                System.out.println("No Input received");
            }
    }

    public static void handleFinancialRequest(){
            try {
                System.out.println("Do you want to accept or reject: ");
                String response=universityManager.Reader.readLine();
                boolean response_flag=false;
                if(response.equals("accept"))
                    response_flag=true;
                else if (response.equals("reject"))
                    response_flag=false;
                else{
                    System.out.println("Invalid input");
                    return;
                }
                System.out.println("enter the number of the requests you want to handle separated with commas");
                String requests[]=universityManager.Reader.readLine().split(",");
                Arrays.sort(requests);
                int requestNumbers[]=new int[requests.length];
                int pointer=0;
                for(String request:requests){
                    int request_number= Integer.parseInt(request);
                    if(request_number> universityManager.financialRequests.size()||request_number<=0) {
                        System.out.println("Invalid Request Numbers");
                        return;
                    }
                    requestNumbers[pointer++]=request_number;
                }
                for(int request_number=requestNumbers.length-1;request_number>=0;request_number--) {
                    var current_request = universityManager.financialRequests.get(request_number - 1);
                    if (response_flag) {
                        ((StudentAccount) current_request).setFinancialAided(true);
                        System.out.println("Request Accepted");
                    } else
                        System.out.println("Request Rejected");
                    universityManager.accountRequests.remove(current_request);
                }

            } catch (IOException e) {
                System.out.println("No Input received");
            }

    }
    public static void addCourse(){

        try {
            System.out.println("enter the name of the course: ");
            String name= universityManager.Reader.readLine();
            AtomicBoolean found= new AtomicBoolean(false);
            universityManager.courses.forEach(course->{
                if(course.getName().equals(name))
                    found.set(true);
            });
            if(found.get()){
                System.out.println("There exist a course with this name already");
                return;
            }
            System.out.println("enter the credit hours of the course: ");
            int credit_hours= Integer.parseInt(universityManager.Reader.readLine());
            System.out.println("enter the specialization of the course: ");
            String specialization= universityManager.Reader.readLine();
            System.out.println("enter the max students of the course: ");
            int max_students= Integer.parseInt(universityManager.Reader.readLine());
            universityManager.courses.add(new Course(name,credit_hours,max_students,specialization));
            System.out.println("Course added successfully");
        } catch (IOException e) {
            System.out.println("No Input received");
        }catch(NumberFormatException e){
            System.out.println("Wrong format");
        }
    }

    public static void modifyStudentBalance(){
        if(!(universityManager.currentUser !=null&& universityManager.currentUser instanceof Admin)){
            System.out.println("You are not allowed to do that");
            return;
        }
        try {
            System.out.println("enter the id of the student: ");
            String id= universityManager.Reader.readLine();
            AtomicBoolean found= new AtomicBoolean(false);
            AtomicReference<StudentAccount> Student_Found=new AtomicReference<>();
            universityManager.Students.forEach(student->{
                if(student.getId().equals(id)) {
                    found.set(true);
                    Student_Found.set(student);
                }
            });
            if(!found.get()){
                System.out.println("No student with this id");
                return;
            }
            System.out.println("the old balance of the student is: "+Student_Found.get().getBalance());
            System.out.println("enter the new balance: ");
            Double balance= Double.parseDouble(universityManager.Reader.readLine());
            Student_Found.get().setBalance(balance);
            System.out.println("new balance added");
        } catch (IOException e) {
            System.out.println("No Input received");
        }catch(NumberFormatException e){
            System.out.println("Wrong format");
        }
    }

}
