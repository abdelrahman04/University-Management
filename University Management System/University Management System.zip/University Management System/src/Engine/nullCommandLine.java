package Engine;

import Account.StudentAccount;
import Account.TaAccount;
import Engine.universityManager;

import java.io.IOException;

public class nullCommandLine {

    public static void commandline(String input){
        switch(input){
            case "1":help();break;
            case "2":createStudentAccount();break;
            case "3":createTeacherAccount();break;
            case "4":adminSignIn();break;
            case "5":studentSignIn();break;
            case "6":teacherSignIn();break;
            default:universityManager.undefinedCommand();

        }
    }
    public static void help(){
        System.out.println("please enter the number of the command you want\nCommands:\n1-help\n2-create student account\n3-create teacher account\n4-admin sign in\n5-student sign in\n6-teacher sign in");
    }
    public static void adminSignIn(){
        try {
            System.out.println("enter your username: ");
            String name= universityManager.Reader.readLine();
            System.out.println("enter your password: ");
            String password= universityManager.Reader.readLine();
            if(universityManager.admin.compare(name,password)){
                System.out.println("signed in successfully");
                universityManager.currentUser =universityManager.admin;
                adminCommandLine.help();
            }else
                System.out.println("Invalid credentials");
        } catch (IOException e) {
            System.out.println("No Input received");
        }
    }

    public static void studentSignIn(){
        try {
            System.out.println("enter your username: ");
            String name= universityManager.Reader.readLine();
            System.out.println("enter your password: ");
            String password= universityManager.Reader.readLine();
            if(universityManager.studentLogins.containsKey(name)) {
                StudentAccount student=universityManager.studentLogins.get(name);
                if(student.getPassword().equals(password)) {
                    System.out.println("signed in successfully");
                    universityManager.currentUser = student;
                    studentCommandLine.help();
                }
                else
                    System.out.println("Invalid credentials");
            }else
                System.out.println("Invalid credentials");
        } catch (IOException e) {
            System.out.println("No Input received");
        }
    }

    public static void teacherSignIn(){
        try {
            System.out.println("enter your username: ");
            String name= universityManager.Reader.readLine();
            System.out.println("enter your password: ");
            String password= universityManager.Reader.readLine();
            if(universityManager.teacherLogins.containsKey(name)) {
                TaAccount teacher=universityManager.teacherLogins.get(name);
                if(teacher.getPassword().equals(password)) {
                    System.out.println("signed in successfully");
                    universityManager.currentUser = teacher;
                    teacherCommandLine.help();
                }
                else
                    System.out.println("Invalid credentials");
            }else
                System.out.println("Invalid credentials");
        } catch (IOException e) {
            System.out.println("No Input received");
        }
    }
    public static void createStudentAccount(){
        try {
            System.out.println("enter your email: ");
            String email= universityManager.Reader.readLine();
            System.out.println("enter your name: ");
            String name= universityManager.Reader.readLine();
            System.out.println("enter your password: ");
            String password= universityManager.Reader.readLine();
            System.out.println("enter your balance: ");
            double balance=Double.parseDouble(universityManager.Reader.readLine());
            universityManager.accountRequests.add(new StudentAccount(email,name,password,balance));
            System.out.println("request submitted successfully");
        } catch (IOException e) {
            System.out.println("No Input received");
        }catch(NumberFormatException e){
            System.out.println("Wrong format");
        }

    }

    public static void createTeacherAccount() {
        try {
            System.out.println("enter your email: ");
            String email = universityManager.Reader.readLine();
            System.out.println("enter your name: ");
            String name = universityManager.Reader.readLine();
            System.out.println("enter your password: ");
            String password = universityManager.Reader.readLine();
            System.out.println("enter your specialization: ");
            String specialization = universityManager.Reader.readLine();
            universityManager.accountRequests.add(new TaAccount(email, name, password, specialization));
            System.out.println("request submitted successfully");
        } catch (IOException e) {
            System.out.println("No Input received");
        }
    }


}
