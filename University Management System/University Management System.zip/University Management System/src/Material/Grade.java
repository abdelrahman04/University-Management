package Material;

public enum Grade {
    A,B,C,D,E,F,NULL
}
