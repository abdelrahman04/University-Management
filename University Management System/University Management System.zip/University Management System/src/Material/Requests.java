package Material;

import java.io.Serializable;

public interface Requests extends Serializable {
    long serialVersionUID =
            -5849794470654667213L;
    String Print_Request();
}
